declare const styles: {
    app: string;
    topnav: string;
    active: string;
    header: string;
    container: string;
    logo: string;
    navigation: string;
    'social-media': string;
    footer: string;
    copyright: string;
    socialMedia: string;
};
export default styles;
//# sourceMappingURL=AppCustomizer.module.scss.d.ts.map