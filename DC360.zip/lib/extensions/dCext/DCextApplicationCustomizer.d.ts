import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface IDCextApplicationCustomizerProperties {
    Top: string;
    Bottom: string;
}
export default class DCextApplicationCustomizer extends BaseApplicationCustomizer<IDCextApplicationCustomizerProperties> {
    private _topPlaceholder;
    private _bottomPlaceholder;
    onInit(): Promise<void>;
    private _renderPlaceHolders;
    private _onDispose;
}
//# sourceMappingURL=DCextApplicationCustomizer.d.ts.map