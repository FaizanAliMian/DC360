define([], function() {
  return {
    "Title": "DCextApplicationCustomizer"
  }
});