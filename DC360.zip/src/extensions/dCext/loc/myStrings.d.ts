declare interface IDCextApplicationCustomizerStrings {
  Title: string;
}

declare module 'DCextApplicationCustomizerStrings' {
  const strings: IDCextApplicationCustomizerStrings;
  export = strings;
}
