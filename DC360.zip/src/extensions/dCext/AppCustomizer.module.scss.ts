/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_2d8a363c',
  topnav: 'topnav_2d8a363c',
  active: 'active_2d8a363c',
  header: 'header_2d8a363c',
  container: 'container_2d8a363c',
  logo: 'logo_2d8a363c',
  navigation: 'navigation_2d8a363c',
  'social-media': 'social-media_2d8a363c',
  footer: 'footer_2d8a363c',
  copyright: 'copyright_2d8a363c',
  socialMedia: 'socialMedia_2d8a363c'
};

export default styles;
/* tslint:enable */